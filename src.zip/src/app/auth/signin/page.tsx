"use client";
import React from "react";
import SigninForm from "@/components/forms/SigninForm";
import Card from "@/components/ui/Card";
import AuthTransitionWrapper from "@/components/layouts/AuthTransitionWrapper";

const SigninPage: React.FC = () => {
  return (
    <AuthTransitionWrapper>
      <div className="flex flex-col md:flex-row min-h-screen w-full">
        {/* Left side (Image) */}
        <div className="hidden md:block md:w-1/2 bg-gray-100">
          <img
            src="/bileto.png"
            alt="Event illustration"
            className="w-full h-full object-cover"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = "https://via.placeholder.com/600x800?text=Image+Not+Found";
            }}
          />
        </div>

        {/* Right side (Form) */}
        <div className="flex w-full md:w-1/2 items-center justify-center p-8 bg-white">
          <Card className="w-full max-w-md shadow-xl">
            <h2 className="text-3xl font-bold mb-2 text-center">
              Selamat Datang di Bileto.id
            </h2>
            <p className="text-slate-600 mb-6 text-center">
              Masuk untuk mengelola tiket dan acara Anda.
            </p>
            <SigninForm />
          </Card>
        </div>
      </div>
    </AuthTransitionWrapper>
  );
};

export default SigninPage;

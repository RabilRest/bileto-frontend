"use client";
import React from "react";
import ForgotPasswordForm from "@/components/forms/ForgotPassword";
import Card from "@/components/ui/Card";
import AuthTransitionWrapper from "@/components/layouts/AuthTransitionWrapper";

export default function ForgotPasswordPage() {
  return (
    <AuthTransitionWrapper>
    <div className="flex h-screen w-full">
      {/* Left side (Image) */}
      <div className="hidden md:block w-1/2 bg-gray-100">
        <img
          src="/bileto.png"
          alt="Forgot Password Illustration"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Right side (Form) */}
      <div className="flex w-full md:w-1/2 items-center justify-center p-8 bg-white">
        <Card className="w-full max-w-md shadow-xl">
          <h2 className="text-3xl font-bold mb-2 text-center">
            Lupa Password
          </h2>
          <p className="text-slate-600 mb-6 text-center">
            Masukkan email Anda untuk mengatur ulang password.
          </p>

          <ForgotPasswordForm />
        </Card>
      </div>
    </div>
    </AuthTransitionWrapper>
  );
}

"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import api from "@/lib/api";
import { useAuthStore } from "@/lib/zustand/useAuthStore";
import Input from "@/components/ui/Input";
import Label from "@/components/ui/Label";
import Button from "@/components/ui/Button";

export default function SigninForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const login = useAuthStore((s) => s.login);
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.post("/auth/signin", { email, password });
      const { user, token } = res.data;
      login(user, token);
      router.push("/"); // redirect ke root/dashboard
    } catch (err: any) {
      console.error(err);
      alert(err?.response?.data?.error || "Gagal masuk. Periksa email/password.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>Email</Label>
        <Input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="email@contoh.com"
          type="email"
          required
        />
      </div>

      <div>
        <Label>Password</Label>
        <Input
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          type="password"
          required
        />
      </div>

      <div className="flex justify-between items-center">
        <a href="/(auth)/forgot-password" className="text-sm text-sky-600">Lupa password?</a>
      </div>

      <div>
        <Button type="submit" disabled={loading}>
          {loading ? "Masuk..." : "Masuk"}
        </Button>
      </div>
    </form>
  );
}

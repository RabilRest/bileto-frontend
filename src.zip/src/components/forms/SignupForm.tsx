"use client";
import React, { useState } from "react";
import api from "@/lib/api";
import { useAuthStore } from "@/lib/zustand/useAuthStore";
import Input from "@/components/ui/Input";
import Label from "@/components/ui/Label";
import Button from "@/components/ui/Button";

export default function SignupForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const signupStore = useAuthStore((s) => s.signup);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.post("/auth/signup", { name, email, password });
      const { user, token } = res.data;
      signupStore(user, token);
      // redirect handled by page or user can navigate
      alert("Daftar berhasil. Kamu otomatis masuk.");
    } catch (err: any) {
      console.error(err);
      alert(err?.response?.data?.error || "Terjadi kesalahan saat mendaftar.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>Nama</Label>
        <Input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nama lengkap"
          required
        />
      </div>

      <div>
        <Label>Email</Label>
        <Input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="email@contoh.com"
          type="email"
          required
        />
      </div>

      <div>
        <Label>Password</Label>
        <Input
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Minimal 6 karakter"
          type="password"
          minLength={6}
          required
        />
      </div>

      <div>
        <Button type="submit" disabled={loading}>
          {loading ? "Mendaftarkan..." : "Daftar"}
        </Button>
      </div>
    </form>
  );
}
